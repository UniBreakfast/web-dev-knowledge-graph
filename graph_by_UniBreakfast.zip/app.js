import {graphus} from './js/graphus.js'
import {headus} from './js/headus.js'
import {nodus} from './js/nodus.js'
import {linkus} from './js/linkus.js'
import {dialogus} from './js/dialogus.js'

await init()
showBody()

async function init() {
  headus.addEventListener('addnode', () => {
    const query = headus.getQuery()
    dialogus.open('new node', query)
  })
  
  headus.addEventListener('querynode', () => {
    const query = headus.getQuery()
    const node = graphus.getNodeByName(query)

    if (!node) return

    nodus.present(node)

    const links = graphus.getLinksFromId(node.id)

    linkus.present(links)
  })

  dialogus.addEventListener('cancel', e => {
    const {name} = e.detail
    
    dialogus.close(name)
  })
}

function showBody() {
  document.body.removeAttribute('hidden')
}

