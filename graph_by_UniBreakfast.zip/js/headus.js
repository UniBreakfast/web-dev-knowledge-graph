export const headus = new EventTarget
const header = document.querySelector('header')
const addNodeBtn = document.getElementById('add-node')

Object.assign(headus, {
  getQuery() {
    
  },
})

init()

function init() {
  addNodeBtn.onclick = () => {
    const e = new CustomEvent('addnode')
    
    headus.dispatchEvent(e)
  }
}