export const dialogus = new EventTarget

Object.assign(dialogus, {
  open(name, data = {}) {
    const dialog = dialogsMap.get(name)

    if (!dialog) throw new Error('unknown dialog name')

    dialog.showModal()
  },

  close(name) {
    const dialog = dialogsMap.get(name)

    if (!dialogs) throw new Error('unknown dialog name')

    dialog.close()
  },
})

const newNodeDialog = document.getElementById('new-node')

const dialogsMap = new Map([
  ['new node', newNodeDialog], [newNodeDialog, 'new node'],
])

document.body.onclick = ({target}) => {
  if (target.matches('.cancel')) {
    const dialog = target.closest('dialog')
    const name = dialogsMap.get(dialog)
    const detail = {name}
    const e = new CustomEvent('cancel', { detail })
    dialogus.dispatchEvent(e)
  }
}

