export const linkus = new EventTarget

Object.assign(linkus, {
  present(links) {
    
  },

  clear() {
    
  },
})