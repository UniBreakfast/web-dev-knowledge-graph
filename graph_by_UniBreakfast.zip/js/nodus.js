export const nodus = new EventTarget

Object.assign(nodus, {
  present(node) {
    
  },

  clear() {
    
  },
})