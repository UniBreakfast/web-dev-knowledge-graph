export const graphus = new EventTarget

Object.assign(graphus, {
  getNodeByName(name) {
    
  },
  
  getLinksFromId(nodeId) {
    
  },

  addNode(name, description) {
    
  },

  updateNode(id, {name, description}) {
    
  },

  deleteNode(id) {
    
  },

  addLink(fromId, toId, description) {
    
  },

  updateLink(fromId, toId, description) {
    
  },

  deleteLink(fromId, toId) {
    
  },
})